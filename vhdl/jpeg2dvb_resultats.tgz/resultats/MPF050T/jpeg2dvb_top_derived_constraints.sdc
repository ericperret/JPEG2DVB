# Microchip Technology Inc.
# Date: 2026-Nov-23 13:08:29
# This file was generated based on the following SDC source files:
#   /home/eperret/dvb_lot/travail/mpf050t/component/work/PF_CCC_SYS/PF_CCC_SYS_0/PF_CCC_SYS_PF_CCC_SYS_0_PF_CCC.sdc
#   /home/eperret/dvb_lot/travail/mpf050t/component/work/PF_CCC_TVP/PF_CCC_TVP_0/PF_CCC_TVP_PF_CCC_TVP_0_PF_CCC.sdc
#   /home/eperret/dvb_lot/travail/mpf050t/component/work/PF_IOD_TX_CCC_IOD/PF_IOD_TX_CCC_IOD.sdc
#   /home/eperret/dvb_lot/travail/mpf050t/component/work/PF_IOD_TX_CCC_IOD_TR/PF_IOD_TX_CCC_IOD_TR_0/PF_IOD_TX_CCC_IOD_TR.sdc
#   /home/eperret/dvb_lot/travail/mpf050t/component/work/PF_IOD_TX_CCC_IOD/PF_CCC_0/PF_IOD_TX_CCC_IOD_PF_CCC_0_PF_CCC.sdc
#   /home/eperret/dvb_lot/travail/mpf050t/component/work/PF_IOD_TX_SD/PF_IOD_TX_SD.sdc
# *** Any modifications to this file will be lost if derived constraints is re-run. ***
#

create_clock -name {osc_50} -period 20 [ get_ports { osc_50 } ]
create_generated_clock -name {u_horl/u_sys/PF_CCC_SYS_0/pll_inst_0/OUT0} -multiply_by 8 -divide_by 5 -source [ get_pins { u_horl/u_sys/PF_CCC_SYS_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { u_horl/u_sys/PF_CCC_SYS_0/pll_inst_0/OUT0 } ]
create_generated_clock -name {u_horl/u_tvp/PF_CCC_TVP_0/pll_inst_0/OUT0} -multiply_by 7159 -divide_by 25000 -source [ get_pins { u_horl/u_tvp/PF_CCC_TVP_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { u_horl/u_tvp/PF_CCC_TVP_0/pll_inst_0/OUT0 } ]
create_generated_clock -name {u_horl/u_iod/PF_CCC_0/pll_inst_0/OUT0} -multiply_by 4 -source [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/OUT0 } ]
create_generated_clock -name {u_horl/u_iod/PF_CCC_0/pll_inst_0/OUT1} -divide_by 1 -source [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/OUT1 } ]
set_false_path -to [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/LOAD_PHASE_N } ]
set_false_path -to [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/PHASE_DIRECTION } ]
set_false_path -to [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/PHASE_ROTATE } ]
set_false_path -to [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/PHASE_OUT0_SEL } ]
set_false_path -to [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/PHASE_OUT1_SEL } ]
set_false_path -ignore_errors -from [ get_cells { u_horl/u_iod/COREBCLKSCLKALIGN_0/*/genblk1.U_PLL_BCLKSCLKALIGN/hold_state_flag } ] -to [ get_cells { u_horl/u_iod/COREBCLKSCLKALIGN_0/*/genblk1.U_PLL_BCLKSCLKALIGN/current_state[*] } ]
set_false_path -to [ get_pins { u_lvds/u_iod/LANECTRL_ADDR_CMD_0/I_LANECTRL*/HS_IO_CLK_PAUSE } ]
