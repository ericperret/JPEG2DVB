# Microchip Technology Inc.
# Date: 2026-Nov-23 13:52:12
# This file was generated based on the following SDC source files:
#   /home/eperret/dvb_lot/travail/mpf100t/constraint/jpeg2dvb_top_derived_constraints.sdc
#   /home/eperret/dvb_lot/travail/mpf100t/constraint/jpeg2dvb_top.sdc
#

create_clock -name {osc_50} -period 20 [ get_ports { osc_50 } ]
create_clock -name {tvp_sclk} -period 37.037 [ get_ports { tvp_sclk } ]
create_generated_clock -name {u_horl/u_sys/PF_CCC_SYS_0/pll_inst_0/OUT0} -multiply_by 8 -divide_by 5 -source [ get_pins { u_horl/u_sys/PF_CCC_SYS_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { u_horl/u_sys/PF_CCC_SYS_0/pll_inst_0/OUT0 } ]
create_generated_clock -name {u_horl/u_tvp/PF_CCC_TVP_0/pll_inst_0/OUT0} -multiply_by 7159 -divide_by 25000 -source [ get_pins { u_horl/u_tvp/PF_CCC_TVP_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { u_horl/u_tvp/PF_CCC_TVP_0/pll_inst_0/OUT0 } ]
create_generated_clock -name {u_horl/u_iod/PF_CCC_0/pll_inst_0/OUT0} -multiply_by 4 -source [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/OUT0 } ]
create_generated_clock -name {u_horl/u_iod/PF_CCC_0/pll_inst_0/OUT1} -divide_by 1 -source [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/OUT1 } ]
set_false_path -to [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/LOAD_PHASE_N } ]
set_false_path -to [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/PHASE_DIRECTION } ]
set_false_path -to [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/PHASE_ROTATE } ]
set_false_path -to [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/PHASE_OUT0_SEL } ]
set_false_path -to [ get_pins { u_horl/u_iod/PF_CCC_0/pll_inst_0/PHASE_OUT1_SEL } ]
set_false_path -to [ get_pins { u_lvds/u_iod/LANECTRL_ADDR_CMD_0/I_LANECTRL*/HS_IO_CLK_PAUSE } ]
set_false_path -from [ get_ports { tvp_scl tvp_sda } ]
set_false_path -to [ get_ports { tvp_scl tvp_sda tvp_resetb tvp_pdn led_pll led_tvp led_video } ]
set_clock_jitter 0.021421 [ get_clocks { tvp_sclk } ]
set_clock_jitter 0.021421 [ get_clocks { osc_50 } ]
set_clock_jitter 0.15 [ get_clocks { u_horl/u_iod/PF_CCC_0/pll_inst_0/OUT0 } ]
set_clock_jitter 0.135 [ get_clocks { u_horl/u_iod/PF_CCC_0/pll_inst_0/OUT1 } ]
set_clock_jitter 1.74605 [ get_clocks { u_horl/u_tvp/PF_CCC_TVP_0/pll_inst_0/OUT0 } ]
set_clock_jitter 0.135 [ get_clocks { u_horl/u_sys/PF_CCC_SYS_0/pll_inst_0/OUT0 } ]
set_clock_groups  -asynchronous -group [ get_clocks { tvp_sclk } ]
