--==============================================================================
--  Nom        : jpeg2dvb_fpga_i2c_tb.vhd
--  Projet     : JPEG2DVB, portage FPGA (émetteur DVB-S 23 cm)
--  Objet      : banc de test de esclave_i2c (jpeg2dvb_fpga_i2c.vhd) : maître I²C
--               modélisé, bus à drain ouvert avec tirage
--  Auteur     : Eric PERRET
--  Date       : 2026-11-24
--  Version    : 1.0
--  Lancement  : ghdl -a --std=08 jpeg2dvb_fpga_i2c.vhd jpeg2dvb_fpga_i2c_tb.vhd
--               ghdl -e --std=08 tb_i2c ; ghdl -r --std=08 tb_i2c
--  Licence    : CC BY-NC 4.0
--  Contrôles  : registre de mode à zéro après la remise à zéro ; écriture puis
--               relecture (pointeur, redémarrage) à 100 kHz et à 400 kHz ;
--               adresse étrangère non acquittée et sans effet ; registres 01h
--               à 07h lus à 00h, écritures acquittées et sans effet ; lecture
--               sans pointeur ; incrément du pointeur en lecture et en écriture ;
--               écriture 00h → 01h → 02h → 00h
--  Historique : 1.0  2026-11-24  création
--==============================================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_i2c is
end entity tb_i2c;

architecture sim of tb_i2c is
    signal clk    : std_logic := '0';
    signal rst    : std_logic := '1';
    signal scl    : std_logic := '1';
    signal sda    : std_logic;
    signal m_sda  : std_logic := '1';
    signal s_oe   : std_logic;
    signal s_sda_i: std_logic;
    signal mode   : std_logic_vector(7 downto 0);
    signal fini   : boolean := false;
    signal erreurs: natural := 0;
begin
    clk <= not clk after 6.25 ns when not fini;

    -- bus : drain ouvert, tirage vers 1
    sda <= '0' when m_sda = '0' else 'Z';
    sda <= '0' when s_oe = '1' else 'Z';
    sda <= 'H';
    s_sda_i <= to_x01(sda);

    dut : entity work.esclave_i2c
        port map (clk => clk, rst => rst, scl_in => scl, sda_in => s_sda_i, sda_oe => s_oe, mode => mode);

    process
        variable demi : time := 5 us;   -- demi-période de SCL

        procedure attendre(t : time) is begin wait for t; end procedure;

        procedure start is
        begin
            m_sda <= '1'; scl <= '1'; attendre(demi);
            m_sda <= '0'; attendre(demi);
            scl <= '0'; attendre(demi / 2);
        end procedure;

        procedure arret is
        begin
            m_sda <= '0'; attendre(demi / 2);
            scl <= '1'; attendre(demi);
            m_sda <= '1'; attendre(demi);
        end procedure;

        -- envoi d'un octet, rend l'acquittement (0 = ACK)
        procedure ecrire(o : std_logic_vector(7 downto 0); variable ack : out std_logic) is
        begin
            for i in 7 downto 0 loop
                m_sda <= o(i); attendre(demi / 2);
                scl <= '1'; attendre(demi);
                scl <= '0'; attendre(demi / 2);
            end loop;
            m_sda <= '1'; attendre(demi / 2);
            scl <= '1'; attendre(demi / 2);
            ack := to_x01(sda);
            attendre(demi / 2);
            scl <= '0'; attendre(demi / 2);
        end procedure;

        -- lecture d'un octet, ack_m : 0 = ACK du maître, 1 = NACK
        procedure lire(variable o : out std_logic_vector(7 downto 0); ack_m : std_logic) is
        begin
            m_sda <= '1';
            for i in 7 downto 0 loop
                attendre(demi / 2);
                scl <= '1'; attendre(demi / 2);
                o(i) := to_x01(sda);
                attendre(demi / 2);
                scl <= '0'; attendre(demi / 2);
            end loop;
            m_sda <= ack_m; attendre(demi / 2);
            scl <= '1'; attendre(demi);
            scl <= '0'; attendre(demi / 2);
            m_sda <= '1';
        end procedure;

        procedure verifie(ok : boolean; msg : string) is
        begin
            if not ok then
                report "ECHEC : " & msg severity error;
                erreurs <= erreurs + 1;
            end if;
        end procedure;

        -- ecrit_reg : adresse, pointeur, données (n octets)
        procedure ecrit_reg(adr : std_logic_vector(6 downto 0); p : std_logic_vector(7 downto 0);
                            d1 : std_logic_vector(7 downto 0); n : natural; variable ack_a : out std_logic) is
            variable a : std_logic;
        begin
            start;
            ecrire(adr & '0', a); ack_a := a;
            if a = '0' then
                ecrire(p, a);
                if n >= 1 then ecrire(d1, a); end if;
            end if;
            arret;
        end procedure;

        procedure lit_reg(adr : std_logic_vector(6 downto 0); p : std_logic_vector(7 downto 0);
                          variable r : out std_logic_vector(7 downto 0); variable ack_a : out std_logic) is
            variable a : std_logic;
            variable o : std_logic_vector(7 downto 0);
        begin
            start;
            ecrire(adr & '0', a); ack_a := a;
            if a = '0' then
                ecrire(p, a);
                start;                                  -- redémarrage
                ecrire(adr & '1', a);
                lire(o, '1');
                r := o;
            else
                r := x"EE";
            end if;
            arret;
        end procedure;

        variable ack : std_logic;
        variable r   : std_logic_vector(7 downto 0);
        constant ADR : std_logic_vector(6 downto 0) := "0101010";
    begin
        attendre(2 us);
        rst <= '0';
        attendre(20 us);
        verifie(mode = x"00", "mode non nul après remise à zéro");

        -- écriture 01h puis relecture
        ecrit_reg(ADR, x"00", x"01", 1, ack);
        verifie(ack = '0', "adresse 2Ah non acquittée");
        verifie(mode = x"01", "mode 01h non écrit");
        lit_reg(ADR, x"00", r, ack);
        verifie(r = x"01", "relecture 01h");

        -- écriture 02h puis relecture
        ecrit_reg(ADR, x"00", x"02", 1, ack);
        verifie(mode = x"02", "mode 02h non écrit");
        lit_reg(ADR, x"00", r, ack);
        verifie(r = x"02", "relecture 02h");

        -- adresse étrangère : pas d'ACK, pas d'effet
        ecrit_reg("0101011", x"00", x"05", 1, ack);
        verifie(ack = '1', "adresse étrangère acquittée");
        verifie(mode = x"02", "mode modifié par une adresse étrangère");
        lit_reg("0010101", x"00", r, ack);
        verifie(ack = '1' and r = x"EE", "lecture à une adresse étrangère");

        -- registres 01h à 07h : lus à 00h, écritures sans effet
        for p in 1 to 7 loop
            ecrit_reg(ADR, std_logic_vector(to_unsigned(p, 8)), x"A5", 1, ack);
            verifie(ack = '0', "écriture hors registre non acquittée");
            verifie(mode = x"02", "mode modifié par une écriture hors registre");
            lit_reg(ADR, std_logic_vector(to_unsigned(p, 8)), r, ack);
            verifie(r = x"00", "lecture hors registre différente de 00h");
        end loop;

        -- 400 kHz
        demi := 1.25 us;
        ecrit_reg(ADR, x"00", x"00", 1, ack);
        verifie(mode = x"00", "mode 00h non écrit à 400 kHz");
        ecrit_reg(ADR, x"00", x"01", 1, ack);
        lit_reg(ADR, x"00", r, ack);
        verifie(r = x"01", "relecture à 400 kHz");
        demi := 5 us;

        -- lecture sans pointeur : reprend au pointeur courant (7+1 = 0 après les écritures
        -- hors registre, puis pointeur 0 posé par ecrit_reg)
        start;
        ecrire(ADR & '1', ack);
        verifie(ack = '0', "lecture directe non acquittée");
        lire(r, '1');
        arret;
        verifie(r = x"01" or r = x"00", "lecture directe : octet inattendu");

        -- écriture multi-octets : pointeur 00h, données 02h puis A5h (A5h au registre 01h : ignoré)
        start;
        ecrire(ADR & '0', ack);
        ecrire(x"00", ack);
        ecrire(x"02", ack);
        ecrire(x"A5", ack);
        arret;
        verifie(mode = x"02", "écriture multi-octets : mode");

        -- lecture multi-octets : 00h puis 00h (registre 01h)
        start;
        ecrire(ADR & '0', ack);
        ecrire(x"00", ack);
        start;
        ecrire(ADR & '1', ack);
        lire(r, '0');
        verifie(r = x"02", "lecture multi-octets : premier octet");
        lire(r, '1');
        verifie(r = x"00", "lecture multi-octets : second octet");
        arret;

        -- retour au mode automatique
        ecrit_reg(ADR, x"00", x"00", 1, ack);
        verifie(mode = x"00", "retour à 00h");

        -- remise à zéro pendant que le mode vaut 01h
        ecrit_reg(ADR, x"00", x"01", 1, ack);
        rst <= '1'; attendre(1 us); rst <= '0'; attendre(5 us);
        verifie(mode = x"00", "remise à zéro sans effet");

        attendre(20 us);
        if erreurs = 0 then
            report "tb_i2c : TOUS LES CONTROLES SONT OK";
        else
            report "tb_i2c : " & integer'image(erreurs) & " ERREUR(S)" severity failure;
        end if;
        fini <= true;
        wait;
    end process;
end architecture sim;
